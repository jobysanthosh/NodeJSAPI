console.log('Hi');

// setTimeout(() => {
//     console.log("there !");
// }, 2000);

setTimeout(function(){
    console.log("there !");
}, 2000);

